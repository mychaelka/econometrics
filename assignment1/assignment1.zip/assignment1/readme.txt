Output of the assignment can be found at https://anhonestwork.github.io/

